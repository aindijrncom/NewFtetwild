#!/bin/bash
./TetWild --input input.stl --level 3
./TetWild --input input.stl --bg-mesh bg_mesh.msh  --stop-energy 20 --level 3